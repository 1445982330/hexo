declare class configs {
  root: string
  search: {
    preload: string
    activeHolder: string
    blurHolder: string
    noResult: string
  }
  code: {
    copy: string
    copyFinish: string
    codeInfo: string
    expand: string
  }
}
declare var config: configs
