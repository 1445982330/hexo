if(!!window.ActiveXObject || "ActiveXObject" in window){
    window.location.href="./noie.html";
}