---
title: fontawesome对照
date: 2022-11-25 08:16:09
---

<iframe id="ifm" src="https://fontawesome.com.cn/faicons/" width="100%" height="13000px" frameborder="0"></iframe>
<script>
    window.parent.postMessage(object,'*');
document.getElementById('ifm').scroll(0,document.getElementById('ifm').document.body.scrollHeight);
</script>