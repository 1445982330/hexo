export { default as Title } from './src/Title.vue'
export { default as SubTitle } from './src/SubTitle.vue'
