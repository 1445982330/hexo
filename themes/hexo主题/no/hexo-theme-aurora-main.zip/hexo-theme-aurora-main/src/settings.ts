export default {
  title: process.env.VUE_APP_PROJECT_TITLE || 'TriDiamond Blog'
}
