const zh_CN = {
  "title":"标题"
}
export default zh_CN;