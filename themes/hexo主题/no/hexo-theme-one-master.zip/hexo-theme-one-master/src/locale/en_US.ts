const en_US = {
  "title":"Title"
}
export default en_US;