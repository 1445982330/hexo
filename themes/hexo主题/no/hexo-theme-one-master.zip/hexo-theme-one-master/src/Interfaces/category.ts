import { post } from './post';
export interface category {
  name?:string,
  postlist?:Array<post>
}