import { post } from './post';
export interface tag {
  name?:string,
  postlist?:Array<post>
}