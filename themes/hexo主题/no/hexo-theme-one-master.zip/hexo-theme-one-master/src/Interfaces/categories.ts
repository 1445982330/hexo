export interface categoriesItem {
  name:string;
  path:string;
}