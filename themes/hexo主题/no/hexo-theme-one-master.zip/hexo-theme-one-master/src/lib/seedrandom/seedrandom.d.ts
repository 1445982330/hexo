interface Math {
  seedrandom(str:string):number;
}