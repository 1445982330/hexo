# 特色 Features

> 为数不多的非「性冷淡」Material 风Hexo主题。推荐死宅食用~

![](./screenshot.png)