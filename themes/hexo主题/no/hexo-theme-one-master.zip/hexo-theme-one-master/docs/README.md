# 文档 Document

> 欢迎使用 hexo-theme-one!

这里是文档喵，使用前请<b>大声朗读！</b>

* 本主题重写了hexo的诸多功能，但hexo文档仍具有一定参考性

* 文章 = Post

* 页面 = Page

* 本主题所有markdown均支持html

## 目录

[安装](./setup.md)

[基本设置](./setting.md)

[文章 Front-matter](./Post-Front-matter.md)

[页面 Front-matter](./Page-Front-matter.md)

[颜色](./color.md)

[高级设置](./expert.md)