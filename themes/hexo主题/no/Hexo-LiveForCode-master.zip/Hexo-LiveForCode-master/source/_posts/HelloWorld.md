﻿---
title: Hello World
date: 2020-01-01 00:00:00
# 文章出处名称 #
from: Hexo
# 文章出处链接 #
url: https://hexo.io/
# 文章作者名称 #
author: Hexo
# 文章作者签名 #
about: 快速、简洁且高效的博客框架
# 文章作者头像 #
avatar: https://www.notes.worstone.cn/image/hexo.png
# 是否开启评论 #
comments: true
# 文章标签 #
tags: Hexo
# 文章分类 #
categories: Web
# 文章摘要 #
description: Hexo相关资料以及简单的使用教程.
---
Welcome to [Hexo](https://hexo.io/)! This is your very first post. Check [documentation](https://hexo.io/docs/) for more info. If you get any problems when using Hexo, you can find the answer in [troubleshooting](https://hexo.io/docs/troubleshooting.html) or you can ask me on [GitHub](https://github.com/hexojs/hexo/issues).

## Quick Start

### Create a new post

``` bash
$ hexo new "My New Post"
```

More info: [Writing](https://hexo.io/docs/writing.html)

### Run server

``` bash
$ hexo server
```

More info: [Server](https://hexo.io/docs/server.html)

### Generate static files

``` bash
$ hexo generate
```

More info: [Generating](https://hexo.io/docs/generating.html)

### Deploy to remote sites

``` bash
$ hexo deploy
```

More info: [Deployment](https://hexo.io/docs/one-command-deployment.html)
