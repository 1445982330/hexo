---
title    : 关于
date     : 2020-01-01 00:00:00
type     : about
comments : false
---
## 关于我
我是一个在命运长河里挣扎的小鱼，90后，目前是小白一枚。
虽然心中不甘，但是目前确实是 __Worst One__ 。
目标是成为全栈工程师、系统架构师。虽然前路迷茫，但是我会一步一步往前走。
## 关于主题
[Hexo - LiveForCode](https://github.com/first19326/Hexo-LiveForCode/) 主题是根据 [BNDong](https://dbnuo.com/) 的博客样式复制过来的，其中也借鉴了 [Hexo - NexT](http://theme-next.iissnan.com/) 主题的样式。可能这个主题还有很多不尽人意的地方，在后续的阶段我会不断地完善，如果有关于主题的相关问题，欢迎联系我。
