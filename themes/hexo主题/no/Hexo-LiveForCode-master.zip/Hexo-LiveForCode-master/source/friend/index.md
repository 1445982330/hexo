---
title    : 友情链接
date     : 2020-01-01 00:00:00
type     : friend
comments : false
# 样式 rotate translate  
# 默认 rotate
style    : rotate
friends  : 
  - 
    head        : 特别鸣谢
    description : 
    friend      :
      - 
        name    : Hexo
        avatar  : /image/friend/hexo.png
        url     : https://hexo.io/zh-cn/
        about   : 简洁、高效的博客框架
      - 
        name    : BNDong
        avatar  : /image/friend/bndong.gif
        url     : https://blog.dbnuo.com/
        about   : SimpleMemory 作者
      - 
        name    : IIssNan
        avatar  : /image/friend/iissnan.jpg
        url     : https://notes.iissnan.com/
        about   : Hexo-NexT 作者
      - 
        name    : Volantis
        avatar  : /image/friend/volantis.png
        url     : https://volantis.js.org/
        about   : Hexo-Volantis 主题
  - 
    head        : 友情链接
    description : 
    friend      :
      - 
        name    : WorstOne
        avatar  : /image/sidebar/avatar.jpg
        url     : https://notes.worstone.cn
        about   : Live For Code 作者
---
> 欢迎各位朋友前来交换友链，本站友链接受以下类型的网站：
> - 个人博客
> - 公益组织等非盈利性网站
> - 不接受广告、商业性网站，特殊情况除外
> 
> 如果你的网站 __一个月以上无法正常访问__ 将会被移除。
